v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
T {Banba sub-1V bandgap topology (JSSC May 1999) on gf180mcu, VDD=3.3V} 100 -880 0 0 0.4 0.4 {}
T {Vref = R4*(Vf/R1 + dVf/R3) ~= 1.20V, ~3.6ppm/C (tt)} 100 -850 0 0 0.3 0.3 {}
T {I=1  (D1)} 150 -330 0 0 0.22 0.22 {}
T {N=8 (D2)} 540 -300 0 0 0.22 0.22 {}
T {startup: injects into va until VREF rises} 920 -680 0 0 0.25 0.25 {}
T {current outputs: IREF ~4uA source (M4), IREF2X ~8uA source (M5, m doubled),} 1250 -700 0 0 0.25 0.25 {}
T {ISINK ~4uA sink (M6 -> MND/MNS NMOS mirror, for biasing PMOS loads)} 1250 -675 0 0 0.25 0.25 {}
N 140 -620 1640 -620 {lab=VDD}
N 100 -220 1780 -220 {lab=VSS}
N 220 -620 220 -590 {lab=VDD}
N 500 -620 500 -590 {lab=VDD}
N 780 -620 780 -590 {lab=VDD}
N 1000 -620 1000 -590 {lab=VDD}
N 1160 -620 1160 -590 {lab=VDD}
N 1320 -620 1320 -590 {lab=VDD}
N 1480 -620 1480 -590 {lab=VDD}
N 1640 -620 1640 -590 {lab=VDD}
N 150 -560 180 -560 {lab=vg}
N 430 -560 460 -560 {lab=vg}
N 710 -560 740 -560 {lab=vg}
N 1250 -560 1280 -560 {lab=vg}
N 1410 -560 1440 -560 {lab=vg}
N 1570 -560 1600 -560 {lab=vg}
N 1320 -530 1320 -450 {lab=IREF}
N 1320 -450 1400 -450 {lab=IREF}
N 1480 -530 1480 -450 {lab=IREF2X}
N 1480 -450 1560 -450 {lab=IREF2X}
N 1640 -530 1640 -430 {lab=vbn}
N 1570 -400 1600 -400 {lab=vbn}
N 1710 -400 1740 -400 {lab=vbn}
N 1640 -370 1640 -220 {lab=VSS}
N 1780 -370 1780 -220 {lab=VSS}
N 1780 -450 1780 -430 {lab=ISINK}
N 1780 -450 1860 -450 {lab=ISINK}
N 220 -530 220 -450 {lab=va}
N 500 -530 500 -450 {lab=vb}
N 780 -530 780 -450 {lab=VREF}
N 140 -450 220 -450 {lab=va}
N 140 -450 140 -410 {lab=va}
N 220 -450 220 -410 {lab=va}
N 140 -350 140 -220 {lab=VSS}
N 220 -350 220 -220 {lab=VSS}
N 420 -450 500 -450 {lab=vb}
N 420 -450 420 -410 {lab=vb}
N 500 -450 500 -410 {lab=vb}
N 420 -350 420 -220 {lab=VSS}
N 500 -350 500 -320 {lab=vd2}
N 500 -260 500 -220 {lab=VSS}
N 700 -450 780 -450 {lab=VREF}
N 780 -450 880 -450 {lab=VREF}
N 700 -450 700 -410 {lab=VREF}
N 780 -450 780 -410 {lab=VREF}
N 700 -350 700 -220 {lab=VSS}
N 780 -350 780 -220 {lab=VSS}
N 1000 -530 1000 -480 {lab=st}
N 1000 -420 1000 -220 {lab=VSS}
N 930 -450 960 -450 {lab=VREF}
N 1160 -530 1160 -490 {lab=#net1}
N 1090 -460 1120 -460 {lab=st}
N 1160 -430 1160 -400 {lab=va}
C {symbols/pfet_03v3.sym} 200 -560 0 0 {name=M1
L=5u
W=5u
nf=1
m=4}
C {symbols/pfet_03v3.sym} 480 -560 0 0 {name=M2
L=5u
W=5u
nf=1
m=4}
C {symbols/pfet_03v3.sym} 760 -560 0 0 {name=M3
L=5u
W=5u
nf=1
m=4}
C {symbols/pfet_03v3.sym} 1300 -560 0 0 {name=M4
L=5u
W=5u
nf=1
m=4}
C {symbols/pfet_03v3.sym} 1460 -560 0 0 {name=M5
L=5u
W=5u
nf=1
m=8}
C {symbols/pfet_03v3.sym} 1620 -560 0 0 {name=M6
L=5u
W=5u
nf=1
m=4}
C {symbols/nfet_03v3.sym} 1620 -400 0 0 {name=MND
L=6u
W=30u
nf=1
m=2}
C {symbols/nfet_03v3.sym} 1760 -400 0 0 {name=MNS
L=6u
W=30u
nf=1
m=2}
C {symbols/ppolyf_u_2k.sym} 140 -380 0 0 {name=R1
W=1u
L=140u
model=ppolyf_u_2k
spiceprefix=X
m=1}
C {symbols/diode_pd2nw_03v3.sym} 220 -380 0 0 {name=D1
model=diode_pd2nw_03v3
r_w=10u
r_l=10u
m=1}
C {symbols/ppolyf_u_2k.sym} 420 -380 0 0 {name=R2
W=1u
L=140u
model=ppolyf_u_2k
spiceprefix=X
m=1}
C {symbols/ppolyf_u_2k.sym} 500 -380 0 0 {name=R3
W=1u
L=13.9u
model=ppolyf_u_2k
spiceprefix=X
m=1}
C {symbols/diode_pd2nw_03v3.sym} 500 -290 0 0 {name=D2
model=diode_pd2nw_03v3
r_w=10u
r_l=10u
m=8}
C {symbols/ppolyf_u_2k.sym} 700 -380 0 0 {name=R4
W=1u
L=141u
model=ppolyf_u_2k
spiceprefix=X
m=1}
C {symbols/cap_mim_2f0fF.sym} 780 -380 0 0 {name=C1
W=30u
L=30u
model=cap_mim_2f0fF
spiceprefix=X
m=1}
C {symbols/ppolyf_u_2k.sym} 1000 -560 0 0 {name=RSU
W=1u
L=1000u
model=ppolyf_u_2k
spiceprefix=X
m=1}
C {symbols/nfet_03v3.sym} 980 -450 0 0 {name=MSD
L=1u
W=10u
nf=1
m=1}
C {symbols/pfet_03v3.sym} 1140 -560 0 0 {name=MSU1
L=20u
W=0.5u
nf=1
m=1}
C {symbols/nfet_03v3.sym} 1140 -460 0 0 {name=MSU2
L=0.28u
W=10u
nf=1
m=1}
C {devices/lab_pin.sym} 150 -560 0 0 {name=p20 sig_type=std_logic lab=vg}
C {devices/lab_pin.sym} 430 -560 0 0 {name=p21 sig_type=std_logic lab=vg}
C {devices/lab_pin.sym} 710 -560 0 0 {name=p22 sig_type=std_logic lab=vg}
C {devices/lab_pin.sym} 1250 -560 0 0 {name=p23 sig_type=std_logic lab=vg}
C {devices/lab_pin.sym} 1410 -560 0 0 {name=p24 sig_type=std_logic lab=vg}
C {devices/lab_pin.sym} 1570 -560 0 0 {name=p25 sig_type=std_logic lab=vg}
C {devices/lab_pin.sym} 1570 -400 0 0 {name=p26 sig_type=std_logic lab=vbn}
C {devices/lab_pin.sym} 1710 -400 0 0 {name=p27 sig_type=std_logic lab=vbn}
C {devices/lab_pin.sym} 1640 -480 0 0 {name=p28 sig_type=std_logic lab=vbn}
C {devices/lab_pin.sym} 140 -450 0 0 {name=p29 sig_type=std_logic lab=va}
C {devices/lab_pin.sym} 420 -450 0 0 {name=p30 sig_type=std_logic lab=vb}
C {devices/lab_pin.sym} 500 -320 0 0 {name=p31 sig_type=std_logic lab=vd2}
C {devices/lab_pin.sym} 1000 -505 0 0 {name=p32 sig_type=std_logic lab=st}
C {devices/lab_pin.sym} 1090 -460 0 0 {name=p33 sig_type=std_logic lab=st}
C {devices/lab_pin.sym} 930 -450 0 0 {name=p34 sig_type=std_logic lab=VREF}
C {devices/lab_pin.sym} 1160 -400 0 0 {name=p35 sig_type=std_logic lab=va}
C {devices/lab_pin.sym} 220 -560 0 0 {name=p36 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 500 -560 0 0 {name=p37 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 780 -560 0 0 {name=p38 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 1160 -560 0 0 {name=p39 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 1320 -560 0 0 {name=p40 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 1480 -560 0 0 {name=p41 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 1640 -560 0 0 {name=p42 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 1640 -400 0 0 {name=p43 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 1780 -400 0 0 {name=p44 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 1120 -560 0 0 {name=p45 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 120 -380 0 0 {name=p46 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 400 -380 0 0 {name=p47 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 480 -380 0 0 {name=p48 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 680 -380 0 0 {name=p49 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 980 -560 0 0 {name=p50 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 1000 -450 0 0 {name=p51 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 1160 -460 0 0 {name=p52 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 120 -780 0 0 {name=p53 sig_type=std_logic lab=vb}
C {devices/lab_pin.sym} 120 -740 0 0 {name=p54 sig_type=std_logic lab=va}
C {devices/lab_pin.sym} 280 -760 0 0 {name=p55 sig_type=std_logic lab=vg}
C {devices/lab_pin.sym} 200 -810 0 0 {name=p56 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 200 -710 0 0 {name=p57 sig_type=std_logic lab=VSS}
C {devices/iopin.sym} 140 -620 0 0 {name=p1 lab=VDD}
C {devices/iopin.sym} 100 -220 0 0 {name=p2 lab=VSS}
C {devices/opin.sym} 880 -450 0 0 {name=p3 lab=VREF}
C {devices/opin.sym} 1400 -450 0 0 {name=p6 lab=IREF}
C {devices/opin.sym} 1560 -450 0 0 {name=p7 lab=IREF2X}
C {devices/opin.sym} 1860 -450 0 0 {name=p8 lab=ISINK}
C {devices/title.sym} 160 -30 0 0 {name=l_title author="Banba BGR / gf180mcu"}
C {bgr_PTAT/ota.sym} 200 -760 0 0 {name=x1}
