v {xschem version=3.4.5 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
T {Two-stage PMOS-input OTA  (drives PMOS mirror gates near VDD)} 60 -680 0 0 0.35 0.35 {}
T {bias ~5uA} 100 -470 0 0 0.25 0.25 {}
T {stage 1} 340 -430 0 0 0.25 0.25 {}
T {stage 2 + Miller Cc/Rz} 600 -450 0 0 0.25 0.25 {}
N 100 -620 820 -620 {}
N 100 -140 820 -140 {}
N 160 -590 160 -620 {}
N 420 -590 420 -620 {}
N 780 -590 780 -620 {}
N 160 -390 160 -140 {}
N 300 -230 300 -140 {}
N 520 -230 520 -140 {}
N 780 -230 780 -140 {}
N 120 -560 120 -510 {}
N 120 -510 760 -510 {}
N 160 -530 160 -510 {}
N 160 -510 160 -450 {}
N 380 -560 380 -510 {}
N 740 -560 740 -510 {}
N 420 -530 420 -480 {}
N 300 -480 540 -480 {}
N 300 -460 300 -480 {}
N 520 -460 520 -480 {}
N 260 -430 240 -430 {}
N 480 -430 460 -430 {}
N 300 -400 300 -290 {}
N 260 -260 230 -260 {}
N 230 -260 230 -310 {}
N 230 -310 300 -310 {}
N 230 -260 230 -200 {}
N 230 -200 450 -200 {}
N 450 -200 450 -260 {}
N 450 -260 480 -260 {}
N 520 -400 520 -290 {}
N 740 -260 700 -260 {}
N 700 -260 700 -390 {}
N 700 -390 520 -390 {}
N 780 -530 780 -290 {}
N 780 -380 880 -380 {}
N 520 -370 600 -370 {}
N 600 -310 600 -280 {}
C {symbols/pfet_03v3.sym} 140 -560 0 0 {name=MBP
L=5u
W=5u
nf=1
m=2}
C {symbols/pfet_03v3.sym} 400 -560 0 0 {name=MT
L=5u
W=5u
nf=1
m=2}
C {symbols/pfet_03v3.sym} 760 -560 0 0 {name=MPL
L=5u
W=5u
nf=1
m=2}
C {symbols/ppolyf_u_2k.sym} 160 -420 0 0 {name=RB
W=1u
L=230u
model=ppolyf_u_2k
spiceprefix=X
m=1}
C {symbols/pfet_03v3.sym} 280 -430 0 0 {name=MP1
L=1u
W=10u
nf=1
m=2}
C {symbols/pfet_03v3.sym} 500 -430 0 0 {name=MP2
L=1u
W=10u
nf=1
m=2}
C {symbols/nfet_03v3.sym} 280 -260 0 0 {name=MN1
L=2u
W=5u
nf=1
m=1}
C {symbols/nfet_03v3.sym} 500 -260 0 0 {name=MN2
L=2u
W=5u
nf=1
m=1}
C {symbols/nfet_03v3.sym} 760 -260 0 0 {name=MN3
L=0.5u
W=10u
nf=1
m=1}
C {symbols/cap_mim_2f0fF.sym} 600 -340 0 0 {name=CC
W=35u
L=35u
model=cap_mim_2f0fF
spiceprefix=X
m=1}
C {symbols/ppolyf_u_2k.sym} 600 -250 0 0 {name=RZ
W=1u
L=10u
model=ppolyf_u_2k
spiceprefix=X
m=1}
C {devices/ipin.sym} 240 -430 0 0 {name=p1 lab=INN}
C {devices/ipin.sym} 460 -430 0 0 {name=p2 lab=INP}
C {devices/opin.sym} 880 -380 0 0 {name=p3 lab=OUT}
C {devices/iopin.sym} 100 -620 0 0 {name=p4 lab=VDD}
C {devices/iopin.sym} 100 -140 0 0 {name=p5 lab=VSS}
C {devices/lab_pin.sym} 600 -220 0 0 {name=p16 sig_type=std_logic lab=OUT}
C {devices/lab_pin.sym} 300 -510 0 0 {name=p17 sig_type=std_logic lab=vbp}
C {devices/lab_pin.sym} 360 -480 0 0 {name=p18 sig_type=std_logic lab=vtail}
C {devices/lab_pin.sym} 300 -345 0 0 {name=p19 sig_type=std_logic lab=n1}
C {devices/lab_pin.sym} 520 -345 0 0 {name=p20 sig_type=std_logic lab=out1}
C {devices/lab_pin.sym} 160 -560 0 0 {name=p21 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 420 -560 0 0 {name=p22 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 780 -560 0 0 {name=p23 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 300 -430 0 0 {name=p24 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 520 -430 0 0 {name=p25 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 300 -260 0 0 {name=p26 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 520 -260 0 0 {name=p27 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 780 -260 0 0 {name=p28 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 140 -420 0 0 {name=p29 sig_type=std_logic lab=VSS}
C {devices/lab_pin.sym} 580 -250 0 0 {name=p30 sig_type=std_logic lab=VSS}
C {devices/title.sym} 160 -30 0 0 {name=l_title author="Banba BGR / gf180mcu"}
