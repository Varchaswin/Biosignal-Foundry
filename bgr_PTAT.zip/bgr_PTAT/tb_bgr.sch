v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
T {VL/VL2 hold the source outputs at 1.2V, VL3 holds the sink at 2.0V;} 560 -370 0 0 0.22 0.22 {}
T {currents = i(vl), i(vl2), i(vl3)} 560 -350 0 0 0.22 0.22 {}
N 140 -320 140 -280 {lab=vdd_net}
N 140 -320 250 -320 {lab=vdd_net}
N 140 -220 140 -190 {lab=GND}
N 250 -280 250 -190 {lab=GND}
N 430 -330 490 -330 {lab=vref}
N 430 -310 540 -310 {lab=iref}
N 540 -250 540 -230 {lab=GND}
N 430 -290 460 -290 {lab=iref2x}
N 460 -290 460 -150 {lab=iref2x}
N 460 -150 640 -150 {lab=iref2x}
N 640 -150 640 -130 {lab=iref2x}
N 640 -70 640 -50 {lab=GND}
N 430 -270 480 -270 {lab=isink}
N 480 -270 480 -190 {lab=isink}
N 480 -190 760 -190 {lab=isink}
N 760 -130 760 -110 {lab=GND}
C {devices/vsource.sym} 140 -250 0 0 {name=V1 value=3.3}
C {devices/vsource.sym} 540 -280 0 0 {name=VL value=1.2}
C {devices/vsource.sym} 640 -100 0 0 {name=VL2 value=1.2}
C {devices/vsource.sym} 760 -160 0 0 {name=VL3 value=2.0}
C {devices/gnd.sym} 140 -190 0 0 {name=l1 lab=GND}
C {devices/gnd.sym} 250 -190 0 0 {name=l2 lab=GND}
C {devices/gnd.sym} 540 -230 0 0 {name=l3 lab=GND}
C {devices/gnd.sym} 640 -50 0 0 {name=l4 lab=GND}
C {devices/gnd.sym} 760 -110 0 0 {name=l5 lab=GND}
C {devices/lab_pin.sym} 490 -330 0 0 {name=p10 sig_type=std_logic lab=vref}
C {devices/lab_pin.sym} 500 -310 0 0 {name=p11 sig_type=std_logic lab=iref}
C {devices/lab_pin.sym} 600 -150 0 0 {name=p12 sig_type=std_logic lab=iref2x}
C {devices/lab_pin.sym} 700 -190 0 0 {name=p13 sig_type=std_logic lab=isink}
C {devices/lab_pin.sym} 140 -300 0 0 {name=p14 sig_type=std_logic lab=vdd_net}
C {devices/code_shown.sym} 970 -620 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
.lib $::180MCU_MODELS/sm141064.ngspice res_typical
.lib $::180MCU_MODELS/sm141064.ngspice diode_typical
.lib $::180MCU_MODELS/sm141064.ngspice mimcap_typical
.lib $::180MCU_MODELS/sm141064.ngspice cap_mim
.param mc_c_cox_2p0fF=0
"}
C {devices/code_shown.sym} 970 -420 0 0 {name=NGSPICE only_toplevel=true
value="
.option savecurrents
.control
save all
* --- temperature sweep ---
dc temp -40 125 5
wrdata tb_banba_bgr_temp.csv v(vref) i(vl) i(vl2) i(vl3)
plot v(vref)
plot i(vl) i(vl2) ylabel 'source currents'
plot -i(vl3) ylabel 'sink current'
* --- supply sweep at 27C ---
*dc v1 0 3.3 0.02
*wrdata tb_banba_bgr_vdd.csv v(vref) i(vl) i(vl2) i(vl3)
*plot v(vref) vs v(vdd_net)
* --- startup transient (uncomment; make V1 a PWL first) ---
* tran 100n 300u uic
*write tb_banba_bgr.raw
*plot v(vref) v(vdd_net)
.endc
"}
C {devices/title.sym} 160 -30 0 0 {name=l_title author="Banba BGR / gf180mcu"}
C {bgr_PTAT/bgr.sym} 340 -300 0 0 {name=x1}
