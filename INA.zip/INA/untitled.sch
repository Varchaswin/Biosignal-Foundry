v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N -80 -60 -10 -60 {lab=Vin}
N -80 -60 -80 40 {lab=Vin}
N -80 40 -10 40 {lab=Vin}
N 30 -30 30 10 {lab=Vout}
N 30 -120 30 -90 {lab=VDD}
N 30 -120 50 -120 {lab=VDD}
N 50 -120 50 -60 {lab=VDD}
N 30 -60 50 -60 {lab=VDD}
N 30 40 50 40 {lab=GND}
N 50 40 50 110 {lab=GND}
N 30 110 50 110 {lab=GND}
N 30 70 30 110 {lab=GND}
N 30 -10 60 -10 {lab=Vout}
N 50 110 80 110 {lab=GND}
N 50 -120 80 -120 {lab=VDD}
N -120 -10 -80 -10 {lab=Vin}
C {symbols/nfet_03v3.sym} 10 40 0 0 {name=M1
L=1u
W=1u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {symbols/pfet_03v3.sym} 10 -60 0 0 {name=M2
L=1u
W=2u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {ipin.sym} -120 -10 0 0 {name=p1 lab=Vin}
C {opin.sym} 60 -10 0 0 {name=p2 lab=Vout}
C {iopin.sym} 80 -120 0 0 {name=p3 lab=VDD}
C {iopin.sym} 80 110 0 0 {name=p4 lab=GND}
