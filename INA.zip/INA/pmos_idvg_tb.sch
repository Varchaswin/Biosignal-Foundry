v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N 260 -590 260 -580 {lab=VG}
N 260 -590 320 -590 {lab=VG}
N 360 -640 360 -620 {lab=VDD}
N 360 -640 510 -640 {lab=VDD}
N 510 -640 510 -620 {lab=VDD}
N 360 -590 370 -590 {lab=VDD}
N 370 -640 370 -590 {lab=VDD}
C {symbols/pfet_03v3_dss.sym} 340 -590 0 0 {name=M1
L=1u
W=5u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
s_sab=0.28u 
d_sab=2.78u 
sa=0 sb=0 sd=0
model=pfet_03v3_dss
spiceprefix=X
}
C {vsource.sym} 510 -590 0 0 {name=VDD value=3.3 savecurrent=false}
C {gnd.sym} 510 -560 0 0 {name=l1 lab=0}
C {vsource.sym} 260 -550 0 0 {name=VG value=3 savecurrent=false}
C {gnd.sym} 360 -560 0 0 {name=l2 lab=0}
C {gnd.sym} 260 -520 0 0 {name=l3 lab=0}
C {lab_wire.sym} 450 -640 0 0 {name=p1 sig_type=std_logic lab=VDD}
C {lab_wire.sym} 300 -590 0 0 {name=p2 sig_type=std_logic lab=VG}
C {devices/code_shown.sym} 290 -460 0 0 {name=NGSPICE only_toplevel=true
value="

.control
save all

write omos_idvg_tb.raw
.endc
"}
C {devices/code_shown.sym} 240 -240 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
"}
