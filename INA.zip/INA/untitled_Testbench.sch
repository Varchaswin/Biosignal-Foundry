v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N 55 55 55 75 {lab=GND}
N -90 -0 -0 -0 {lab=Vin}
N -180 -72.5 -180 -0 {lab=VDD}
N -180 -72.5 60 -72.5 {lab=VDD}
N 60 -72.5 60 -52.5 {lab=VDD}
N 55 65 182.5 65 {lab=GND}
N 182.5 60 182.5 65 {lab=GND}
N 135 -0 182.5 0 {lab=Vout}
N 58.75 -53.75 60 -52.5 {lab=VDD}
N 55 55 56.25 56.25 {lab=GND}
C {untitled.sym} 150 20 0 0 {name=x1}
C {vsource.sym} -90 30 0 0 {name=Vin value=3.3 savecurrent=false}
C {vsource.sym} -180 30 0 0 {name=VDD value=3.3 savecurrent=false}
C {gnd.sym} -90 60 0 0 {name=l1 lab=GND}
C {gnd.sym} -180 60 0 0 {name=l2 lab=GND}
C {gnd.sym} 55 75 0 0 {name=l7 lab=GND}
C {capa.sym} 182.5 30 0 0 {name=C_loaf
m=1
value=1p
footprint=1206
device="ceramic capacitor"}
C {vdd.sym} -25 -72.5 0 0 {name=l3 lab=VDD}
C {lab_wire.sym} -95 -72.5 0 0 {name=p1 sig_type=std_logic lab=VDD}
C {lab_wire.sym} -30 0 0 0 {name=p2 sig_type=std_logic lab=Vin}
C {lab_wire.sym} 175 0 0 0 {name=p3 sig_type=std_logic lab=Vout}
C {lab_wire.sym} 167.5 65 0 0 {name=p4 sig_type=std_logic lab=GND}
C {devices/code_shown.sym} -525 -92.5 0 0 {name=NGSPICE only_toplevel=true
value="

.control
save all

** Define input signal
let fsig = 1k
let tper = 1/fsig
let trf = 0.01*tper
let ton = 0.5*tper-2*tfr

** DefineTransient params
let tstop = 2*tper
let tstep = 0.001*tper

** Set Sources
alter @Vin[DC] = 0.0
alter @Vin[PULSE] = [ 0 3.3 0 $&tfr $&tfr $&ton $&tper 0 ]

write untitled_Testbench.raw
.endc
"
}
C {devices/code_shown.sym} -530 -205 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
"}
