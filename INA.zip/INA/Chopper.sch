v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N -50 -40 -0 -40 {lab=In+}
N -50 -40 -50 70 {lab=In+}
N -50 130 0 130 {lab=In+}
N 120 -40 170 -40 {lab=Vx+}
N 120 130 170 130 {lab=Vx-}
N -50 70 -50 130 {lab=In+}
N 40 -0 40 20 {lab=Phi1b}
N 40 70 40 90 {lab=Phi2}
N 40 -110 40 -80 {lab=Phi1}
N 40 170 40 190 {lab=Phi2b}
N 70 170 70 190 {lab=GND}
N 70 70 70 90 {lab=VDD}
N 70 -0 70 20 {lab=GND}
N 70 -110 70 -80 {lab=VDD}
N -160 10 -120 10 {lab=Phi1}
N -160 90 -120 90 {lab=Phi2}
N -210 -80 -170 -80 {lab=VDD}
N -210 -40 -170 -40 {lab=GND}
N 40 20 40 30 {lab=Phi1b}
N 40 190 40 200 {lab=Phi2b}
N 220 -40 270 -40 {lab=In-}
N 220 -40 220 70 {lab=In-}
N 220 130 270 130 {lab=In-}
N 390 -40 440 -40 {lab=Vx-}
N 390 130 440 130 {lab=Vx+}
N 220 70 220 130 {lab=In-}
N 310 0 310 20 {lab=Phi1b}
N 310 70 310 90 {lab=Phi2}
N 310 -110 310 -80 {lab=Phi1}
N 310 170 310 190 {lab=Phi2b}
N 340 170 340 190 {lab=GND}
N 340 70 340 90 {lab=VDD}
N 340 0 340 20 {lab=GND}
N 340 -110 340 -80 {lab=VDD}
N 310 20 310 30 {lab=Phi1b}
N 310 190 310 200 {lab=Phi2b}
N -160 50 -120 50 {lab=Phi1b}
N -160 120 -120 120 {lab=Phi2b}
N -220 160 -170 160 {lab=Vx+}
N -220 190 -170 190 {lab=Vx-}
C {TG.sym} 130 -40 0 0 {name=xTG+1}
C {TG.sym} 130 130 0 0 {name=xTG-1}
C {opin.sym} -170 160 0 0 {name=p1 lab=Vx+}
C {ipin.sym} -50 40 0 0 {name=p2 lab=In+}
C {iopin.sym} -170 -80 0 0 {name=p3 lab=VDD}
C {ipin.sym} -160 10 0 0 {name=p4 lab=Phi1}
C {ipin.sym} -160 90 0 0 {name=p5 lab=Phi2}
C {iopin.sym} -170 -40 0 0 {name=p6 lab=GND}
C {lab_wire.sym} -180 -40 0 0 {name=p10 sig_type=std_logic lab=GND}
C {lab_wire.sym} 70 10 3 0 {name=p11 sig_type=std_logic lab=GND}
C {lab_wire.sym} 70 180 3 0 {name=p12 sig_type=std_logic lab=GND}
C {lab_wire.sym} -120 10 0 0 {name=p13 sig_type=std_logic lab=Phi1}
C {lab_wire.sym} -120 90 0 0 {name=p14 sig_type=std_logic lab=Phi2}
C {lab_wire.sym} 40 -100 0 0 {name=p15 sig_type=std_logic lab=Phi1}
C {lab_wire.sym} 310 -100 0 0 {name=p16 sig_type=std_logic lab=Phi1}
C {TG.sym} 400 -40 0 0 {name=xTG+2}
C {TG.sym} 400 130 0 0 {name=xTG-2}
C {opin.sym} -170 190 0 0 {name=p18 lab=Vx-}
C {ipin.sym} 220 40 0 0 {name=p19 lab=In-}
C {lab_wire.sym} 340 10 3 0 {name=p22 sig_type=std_logic lab=GND}
C {lab_wire.sym} 340 180 3 0 {name=p23 sig_type=std_logic lab=GND}
C {lab_wire.sym} 40 80 0 0 {name=p24 sig_type=std_logic lab=Phi2}
C {lab_wire.sym} 310 80 0 0 {name=p25 sig_type=std_logic lab=Phi2}
C {ipin.sym} -160 50 0 0 {name=p7 lab=Phi1b}
C {lab_wire.sym} -120 50 0 0 {name=p8 sig_type=std_logic lab=Phi1b}
C {ipin.sym} -160 120 0 0 {name=p9 lab=Phi2b}
C {lab_wire.sym} -120 120 0 0 {name=p20 sig_type=std_logic lab=Phi2b}
C {lab_wire.sym} -180 160 0 0 {name=p21 sig_type=std_logic lab=Vx+}
C {lab_wire.sym} -180 190 0 0 {name=p27 sig_type=std_logic lab=Vx-}
C {lab_wire.sym} -180 -80 0 0 {name=p28 sig_type=std_logic lab=VDD}
C {lab_wire.sym} 70 -100 1 0 {name=p29 sig_type=std_logic lab=VDD}
C {lab_wire.sym} 70 80 1 0 {name=p30 sig_type=std_logic lab=VDD}
C {lab_wire.sym} 340 -100 1 0 {name=p31 sig_type=std_logic lab=VDD}
C {lab_wire.sym} 340 80 1 0 {name=p32 sig_type=std_logic lab=VDD}
C {lab_wire.sym} 170 -40 0 0 {name=p33 sig_type=std_logic lab=Vx+}
C {lab_wire.sym} 440 130 0 0 {name=p34 sig_type=std_logic lab=Vx+}
C {lab_wire.sym} 160 130 0 0 {name=p35 sig_type=std_logic lab=Vx-}
C {lab_wire.sym} 430 -40 0 0 {name=p36 sig_type=std_logic lab=Vx-}
C {lab_wire.sym} 310 30 0 0 {name=p17 sig_type=std_logic lab=Phi1b}
C {lab_wire.sym} 310 200 0 0 {name=p37 sig_type=std_logic lab=Phi2b}
C {lab_wire.sym} 40 200 0 0 {name=p26 sig_type=std_logic lab=Phi2b}
C {lab_wire.sym} 40 30 0 0 {name=p38 sig_type=std_logic lab=Phi1b}
