v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
P 4 1 550 20 {}
N -50 50 -10 50 {lab=VinN}
N -10 30 -10 50 {lab=VinN}
N -10 30 -0 30 {lab=VinN}
N -50 -30 -10 -30 {lab=VinP}
N -10 -30 -10 -10 {lab=VinP}
N -10 -10 -0 -10 {lab=VinP}
N 420 -10 540 -10 {lab=VoutP}
N 540 -10 540 30 {lab=VoutP}
N 420 30 480 30 {lab=VoutN}
N -20 -180 -20 -160 {lab=VPhi1}
N 50 -180 50 -50 {lab=VPhi1}
N 160 -180 160 -150 {lab=VPhi2}
N 110 -180 110 -50 {lab=VPhi2}
N -20 -180 50 -180 {lab=VPhi1}
N 110 -180 160 -180 {lab=VPhi2}
N -10 110 -10 130 {lab=VPhi1b}
N 160 110 160 130 {lab=VPhi2b}
N -10 110 50 110 {lab=VPhi1b}
N 50 70 50 110 {lab=VPhi1b}
N 110 70 110 110 {lab=VPhi2b}
N 110 110 160 110 {lab=VPhi2b}
N 250 30 260 30 {lab=VchopN}
N 250 -10 260 -10 {lab=VchopP}
N 240 -180 240 -160 {lab=VPhi1}
N 310 -180 310 -50 {lab=VPhi1}
N 420 -180 420 -150 {lab=VPhi2}
N 370 -180 370 -50 {lab=VPhi2}
N 240 -180 310 -180 {lab=VPhi1}
N 370 -180 420 -180 {lab=VPhi2}
N 250 110 250 130 {lab=VPhi1b}
N 420 110 420 130 {lab=VPhi2b}
N 250 110 310 110 {lab=VPhi1b}
N 310 70 310 110 {lab=VPhi1b}
N 370 70 370 110 {lab=VPhi2b}
N 370 110 420 110 {lab=VPhi2b}
N 160 30 250 30 {lab=VchopN}
N 160 -10 250 -10 {lab=VchopP}
C {Chopper.sym} 150 10 0 0 {name=x1}
C {vsource.sym} -110 -130 0 0 {name=VDD value=3.3 savecurrent=false}
C {vdd.sym} 80 -50 0 0 {name=l1 lab=VDD}
C {vdd.sym} -110 -160 0 0 {name=l2 lab=VDD}
C {gnd.sym} -110 -100 0 0 {name=l3 lab=0}
C {gnd.sym} 80 70 0 0 {name=l4 lab=0}
C {vsource.sym} -80 -30 1 0 {name=VinP value=3.3 savecurrent=false}
C {gnd.sym} -110 -30 1 0 {name=l5 lab=0}
C {vsource.sym} -80 50 1 0 {name=VinN value=3.3 savecurrent=false}
C {gnd.sym} -110 50 1 0 {name=l6 lab=0}
C {lab_wire.sym} -10 -30 0 0 {name=p1 sig_type=std_logic lab=VinP}
C {lab_wire.sym} -10 50 0 0 {name=p2 sig_type=std_logic lab=VinN}
C {capa.sym} 480 60 0 0 {name=C2
m=1
value=1p
footprint=1206
device="ceramic capacitor"}
C {capa.sym} 540 60 0 0 {name=C1
m=1
value=1p
footprint=1206
device="ceramic capacitor"}
C {gnd.sym} 480 90 0 0 {name=l7 lab=0}
C {gnd.sym} 540 90 0 0 {name=l8 lab=0}
C {lab_wire.sym} 470 -10 0 0 {name=p3 sig_type=std_logic lab=VoutP}
C {lab_wire.sym} 470 30 0 0 {name=p4 sig_type=std_logic lab=VoutN}
C {vsource.sym} -20 -130 0 0 {name=VPhi1 value=3.3 savecurrent=false}
C {gnd.sym} -20 -100 0 0 {name=l9 lab=0}
C {vsource.sym} 160 -120 0 0 {name=VPhi2 value=3.3 savecurrent=false}
C {gnd.sym} 160 -90 0 0 {name=l10 lab=0}
C {lab_wire.sym} 40 -180 0 0 {name=p5 sig_type=std_logic lab=VPhi1}
C {lab_wire.sym} 150 -180 0 0 {name=p6 sig_type=std_logic lab=VPhi2}
C {devices/code_shown.sym} 605 -622.5 0 0 {name=NGSPICE only_toplevel=true
value="

.control
save all

** Define input signal
let vcm = 1.65
let vinpp = 1m
let vinamp = vinpp/4
let fsig = 10

** Define chopper clock
let vddval = 3.3
let fchop = 2k
let tper = 1/fchop

let trf = 20n
let tno = 500n
let ton = 0.5*tper - tno
let tdelay2 = 0.5*tper

** DefineTransient params
let tstop = 0.07
let tstep = 100n

** Set Input Sources
alter @VinP[DC] = 0.0
alter @VinN[DC] = 0.0

alter @VinP[SIN] = [ $&vcm $&vinamp $&fsig 0 0 0 ]
alter @VinN[SIN] = [ $&vcm $&vinamp $&fsig 0 0 180 ]

** Set Non Overlapping Clock
alter @VPhi1[DC] = 0.0
alter @VPhi2[DC] = 0.0
alter @VPhi1b[DC] = 0.0
alter @VPhi2b[DC] = 0.0

alter @VPhi1[PULSE] = [ 0 $&vddval 0 $&trf $&trf $&ton $&tper 0 ]
alter @VPhi2[PULSE] = [ 0 $&vddval $&tdelay2 $&trf $&trf $&ton $&tper 0 ]
alter @VPhi1b[PULSE] = [ $&vddval 0 0 $&trf $&trf $&ton $&tper 0 ]
alter @VPhi2b[PULSE] = [ $&vddval 0 $&tdelay2 $&trf $&trf $&ton $&tper 0 ]

** Run Trans
tran  $&tstep  $&tstop

**Save raw data
write Chopper_tran.raw
wrdata Chopper_tran.txt time v(vinp) c(vinn) v(voutp) v(voutn) v(vphi1) v(vphi2)

** Plot
plot v(vinp)-v(vinn) v(voutp)-v(voutn)
**plot v(vphi1) v(vphi2)
**plot v(vinp) v(vinn)
plot v(voutp) v(voutn)

.endc
"
}
C {devices/code_shown.sym} -200 -285 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
"}
C {vsource.sym} -10 160 0 0 {name=VPhi1b value=3.3 savecurrent=false}
C {gnd.sym} -10 190 0 0 {name=l11 lab=0}
C {vsource.sym} 160 160 0 0 {name=VPhi2b value=3.3 savecurrent=false}
C {gnd.sym} 160 190 0 0 {name=l12 lab=0}
C {lab_wire.sym} 40 110 0 0 {name=p7 sig_type=std_logic lab=VPhi1b}
C {lab_wire.sym} 160 110 0 0 {name=p8 sig_type=std_logic lab=VPhi2b}
C {Chopper.sym} 410 10 0 0 {name=x2}
C {vdd.sym} 340 -50 0 0 {name=l13 lab=VDD}
C {gnd.sym} 340 70 0 0 {name=l14 lab=0}
C {lab_wire.sym} 230 -10 0 0 {name=p9 sig_type=std_logic lab=VchopP}
C {lab_wire.sym} 290 -180 0 0 {name=p11 sig_type=std_logic lab=VPhi1}
C {lab_wire.sym} 410 -180 0 0 {name=p12 sig_type=std_logic lab=VPhi2}
C {lab_wire.sym} 300 110 0 0 {name=p13 sig_type=std_logic lab=VPhi1b}
C {lab_wire.sym} 420 110 0 0 {name=p14 sig_type=std_logic lab=VPhi2b}
C {lab_wire.sym} 230 30 0 0 {name=p10 sig_type=std_logic lab=VchopN}
