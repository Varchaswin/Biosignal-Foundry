v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N 460 -510 460 -450 {lab=#net1}
N 620 -510 620 -450 {lab=#net2}
N 500 -420 580 -420 {lab=VbB}
N 460 -390 460 -360 {lab=GND}
N 460 -360 620 -360 {lab=GND}
N 620 -390 620 -360 {lab=GND}
N 460 -420 460 -390 {lab=GND}
N 620 -420 620 -390 {lab=GND}
N 460 -600 460 -570 {lab=#net3}
N 460 -600 620 -600 {lab=#net3}
N 620 -600 620 -570 {lab=#net3}
N 540 -620 540 -600 {lab=#net3}
N 460 -540 480 -540 {lab=VDD}
N 600 -540 620 -540 {lab=VDD}
N 540 -680 540 -650 {lab=VDD}
N 540 -710 540 -680 {lab=VDD}
N 380 -540 420 -540 {lab=Vin+}
N 660 -540 710 -540 {lab=Vin-}
N 620 -480 800 -480 {lab=#net2}
N 340 -480 460 -480 {lab=#net1}
N 250 -390 250 -360 {lab=GND}
N 250 -360 460 -360 {lab=GND}
N 250 -480 250 -450 {lab=GND}
N 250 -710 540 -710 {lab=VDD}
N 250 -450 250 -390 {lab=GND}
N 290 -480 340 -480 {lab=#net1}
N 250 -600 250 -510 {lab=Vout+}
N 250 -710 250 -660 {lab=VDD}
N 840 -390 840 -360 {lab=GND}
N 840 -480 840 -450 {lab=GND}
N 840 -450 840 -390 {lab=GND}
N 840 -600 840 -510 {lab=Vout-}
N 840 -710 840 -660 {lab=VDD}
N 540 -710 840 -710 {lab=VDD}
N 620 -360 840 -360 {lab=GND}
N 250 -660 250 -630 {lab=VDD}
N 840 -660 840 -630 {lab=VDD}
N 460 -650 500 -650 {lab=Vbtail}
N 180 -630 210 -630 {lab=VbP}
N 880 -630 920 -630 {lab=VbP}
N 250 -560 320 -560 {lab=Vout+}
N 320 -560 320 -550 {lab=Vout+}
N 320 -490 320 -480 {lab=#net1}
N 750 -490 750 -480 {lab=#net2}
N 750 -560 750 -550 {lab=Vout-}
N 750 -560 840 -560 {lab=Vout-}
N 480 -540 600 -540 {lab=VDD}
C {symbols/nfet_03v3.sym} 480 -420 0 1 {name=N1
L=0.28u
W=0.22u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {symbols/nfet_03v3.sym} 600 -420 0 0 {name=N2
L=0.28u
W=0.22u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {symbols/pfet_03v3.sym} 520 -650 0 0 {name=Tail
L=0.28u
W=0.22u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {symbols/pfet_03v3.sym} 440 -540 0 0 {name=P1
L=0.28u
W=0.22u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {symbols/pfet_03v3.sym} 640 -540 0 1 {name=P2
L=0.28u
W=0.22u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {symbols/nfet_03v3.sym} 270 -480 0 1 {name=N3
L=0.28u
W=0.22u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {symbols/pfet_03v3.sym} 230 -630 0 0 {name=P3
L=0.28u
W=0.22u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {symbols/nfet_03v3.sym} 820 -480 0 0 {name=N4
L=0.28u
W=0.22u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {symbols/pfet_03v3.sym} 860 -630 0 1 {name=P4
L=0.28u
W=0.22u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {lab_wire.sym} 490 -650 0 0 {name=p5 sig_type=std_logic lab=Vbtail}
C {lab_wire.sym} 200 -630 0 0 {name=p6 sig_type=std_logic lab=VbP}
C {lab_wire.sym} 910 -630 0 0 {name=p7 sig_type=std_logic lab=VbP}
C {lab_wire.sym} 560 -420 0 0 {name=p8 sig_type=std_logic lab=VbB}
C {lab_wire.sym} 410 -540 0 0 {name=p9 sig_type=std_logic lab=Vin+}
C {lab_wire.sym} 710 -540 0 0 {name=p10 sig_type=std_logic lab=Vin-}
C {lab_wire.sym} 250 -560 0 0 {name=p11 sig_type=std_logic lab=Vout+}
C {lab_wire.sym} 840 -560 0 0 {name=p12 sig_type=std_logic lab=Vout-}
C {lab_wire.sym} 340 -710 0 0 {name=p13 sig_type=std_logic lab=VDD}
C {lab_wire.sym} 340 -360 0 0 {name=p14 sig_type=std_logic lab=GND}
C {capa.sym} 320 -520 0 0 {name=Cmiller+
m=1
value=1p
footprint=1206
device="ceramic capacitor"}
C {capa.sym} 750 -520 0 0 {name=Cmiller-
m=1
value=1p
footprint=1206
device="ceramic capacitor"}
C {lab_wire.sym} 560 -540 0 0 {name=p15 sig_type=std_logic lab=VDD}
