v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N -20 -0 50 -0 {lab=In}
N -20 -0 -20 140 {lab=In}
N -20 140 50 140 {lab=In}
N 200 140 260 140 {lab=Out}
N 260 0 260 140 {lab=Out}
N 200 0 260 0 {lab=Out}
N 80 180 80 200 {lab=EnB}
N 80 -70 80 -40 {lab=En}
N 80 -0 80 30 {lab=GND}
N 80 110 80 140 {lab=VDD}
N 80 200 80 220 {lab=EnB}
N 110 140 200 140 {lab=Out}
N 110 -0 200 -0 {lab=Out}
N 190 120 190 170 {lab=VDD}
N 80 120 190 120 {lab=VDD}
N 160 140 160 170 {lab=Out}
N 220 140 220 170 {lab=Out}
N 160 -30 160 -0 {lab=Out}
N 220 -30 220 -0 {lab=Out}
N 190 -30 190 20 {lab=GND}
N 80 20 190 20 {lab=GND}
N 190 -100 190 -70 {lab=EnB}
N 190 210 190 240 {lab=En}
C {symbols/nfet_03v3.sym} 80 -20 3 1 {name=N
L=0.28u
W=0.42u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {symbols/pfet_03v3.sym} 80 160 3 0 {name=M1
L=0.28u
W=0.84u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
C {opin.sym} 260 70 0 0 {name=p1 lab=Out}
C {ipin.sym} -20 70 0 0 {name=p2 lab=In}
C {ipin.sym} 80 -70 0 0 {name=p3 lab=En}
C {ipin.sym} 80 220 0 0 {name=p4 lab=EnB}
C {iopin.sym} 80 30 0 0 {name=p5 lab=GND}
C {iopin.sym} 80 110 0 0 {name=p7 lab=VDD}
C {lab_wire.sym} 80 -50 0 0 {name=p8 sig_type=std_logic lab=En}
C {lab_wire.sym} 80 210 0 0 {name=p9 sig_type=std_logic lab=EnB}
C {lab_wire.sym} 190 -90 0 0 {name=p6 sig_type=std_logic lab=EnB}
C {lab_wire.sym} 190 240 0 0 {name=p10 sig_type=std_logic lab=En}
C {symbols/nfet_03v3.sym} 190 -50 3 1 {name=N1
L=0.28u
W=0.28u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nfet_03v3
spiceprefix=X
}
C {symbols/pfet_03v3.sym} 190 190 3 0 {name=M2
L=0.28u
W=0.56u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pfet_03v3
spiceprefix=X
}
