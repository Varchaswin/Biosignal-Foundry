v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
P 4 1 620 30 {}
N -50 -30 -10 -30 {lab=in}
N -10 -30 -10 -10 {lab=in}
N -10 -10 -0 -10 {lab=in}
N 130 -10 250 -10 {lab=out}
N 250 -10 250 30 {lab=out}
N -20 -180 -20 -160 {lab=VPhi}
N 50 -180 50 -50 {lab=VPhi}
N -20 -180 50 -180 {lab=VPhi}
N -10 110 -10 130 {lab=VPhib}
N -10 110 50 110 {lab=VPhib}
N 50 30 50 110 {lab=VPhib}
N -0 -10 10 -10 {lab=in}
C {vsource.sym} -110 -130 0 0 {name=VDD value=3.3 savecurrent=false}
C {vdd.sym} 80 -50 0 0 {name=l1 lab=VDD}
C {vdd.sym} -110 -160 0 0 {name=l2 lab=VDD}
C {gnd.sym} -110 -100 0 0 {name=l3 lab=0}
C {gnd.sym} 80 30 0 0 {name=l4 lab=0}
C {vsource.sym} -80 -30 1 0 {name=VForce value=3.3 savecurrent=false}
C {gnd.sym} -110 -30 1 0 {name=l5 lab=0}
C {lab_wire.sym} -10 -30 0 0 {name=p1 sig_type=std_logic lab=in}
C {gnd.sym} 250 90 0 0 {name=l8 lab=0}
C {vsource.sym} -20 -130 0 0 {name=VPhi value=3.3 savecurrent=false}
C {gnd.sym} -20 -100 0 0 {name=l9 lab=0}
C {lab_wire.sym} 30 -180 0 0 {name=p5 sig_type=std_logic lab=VPhi}
C {devices/code_shown.sym} 295 -312.5 0 0 {name=NGSPICE only_toplevel=true
value="

.control
save all


** Ron test for TG
let vddval = 3.3
let itestval = 1u

** Set Sources
alter @VDDP[DC] = $&vddval
alter @VPhi[DC] = $&vddval
alter @VPhib[DC] = 0
alter @Itest[DC] = $&itestval

* Sweeo input 
dc VForce 0.1 3.2 0.01

* Define Ron
let ron = (v(in) - v(out)) / itestval

**Save raw data
write TG_Ron.raw
wrdata TG_Ron.txt v(in) v(out) ron

**Plot
plot ron
plot v(in)-v(out)

.endc
"
}
C {devices/code_shown.sym} -200 -285 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
"}
C {vsource.sym} -10 160 0 0 {name=VPhib value=0 savecurrent=false}
C {gnd.sym} -10 190 0 0 {name=l11 lab=0}
C {lab_wire.sym} 40 110 0 0 {name=p7 sig_type=std_logic lab=VPhib}
C {TG.sym} 140 -10 0 0 {name=x2}
C {isource.sym} 250 60 0 0 {name=Itest value=1u}
C {lab_wire.sym} 190 -10 0 0 {name=p2 sig_type=std_logic lab=out}
