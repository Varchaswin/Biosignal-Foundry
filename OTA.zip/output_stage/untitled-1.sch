v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
N -920 -450 -800 -450 {lab=vin_n}
N -800 -450 -800 -350 {lab=vin_n}
N -920 -370 -880 -370 {lab=#net1}
N -880 -370 -880 -350 {lab=#net1}
N -880 -290 -880 -250 {lab=vss}
N -880 -250 -800 -250 {lab=vss}
N -800 -290 -800 -250 {lab=vss}
N -1010 -350 -1010 -310 {lab=ib}
N -1040 -330 -1040 -310 {lab=vss}
N -1040 -310 -1040 -290 {lab=vss}
N -1010 -250 -1010 -210 {lab=vss}
N -1040 -530 -1040 -490 {lab=vdd}
N -1140 -450 -1040 -450 {lab=vin_p}
N -1140 -370 -1040 -370 {lab=vin_n}
N -1180 -410 -1040 -410 {lab=vocm_set}
N -1180 -410 -1180 -390 {lab=vocm_set}
N -1180 -330 -1180 -290 {lab=vss}
N -1390 -190 -1390 -170 {lab=vss}
N -1390 -170 -1390 -150 {lab=vss}
N -1390 -290 -1390 -250 {lab=vin_cm}
N -1450 -290 -1390 -290 {lab=vin_cm}
N -1450 -310 -1450 -290 {lab=vin_cm}
N -1390 -290 -1380 -290 {lab=vin_cm}
N -1380 -290 -1350 -290 {lab=vin_cm}
N -1350 -310 -1350 -290 {lab=vin_cm}
N -1450 -410 -1450 -370 {lab=vin_p}
N -1350 -410 -1350 -370 {lab=vin_n}
N -1040 -80 -1040 -60 {lab=vss}
N -1040 -180 -1040 -140 {lab=vdd}
N -1040 -60 -1040 -40 {lab=vss}
N -1140 -80 -1140 -40 {lab=0}
N -1140 -180 -1140 -140 {lab=vss}
N -380 -450 -260 -450 {lab=vout_p}
N -260 -450 -260 -350 {lab=vout_p}
N -380 -370 -340 -370 {lab=vout_n}
N -340 -370 -340 -350 {lab=vout_n}
N -340 -290 -340 -250 {lab=vss}
N -340 -250 -260 -250 {lab=vss}
N -260 -290 -260 -250 {lab=vss}
N -470 -350 -470 -310 {lab=ib}
N -500 -330 -500 -310 {lab=vss}
N -500 -310 -500 -290 {lab=vss}
N -470 -250 -470 -210 {lab=vss}
N -500 -530 -500 -490 {lab=vdd}
N -600 -450 -500 -450 {lab=vin_n}
N -600 -370 -500 -370 {lab=#net1}
N -640 -410 -500 -410 {lab=vocm_set}
N -640 -410 -640 -390 {lab=vocm_set}
N -640 -330 -640 -290 {lab=vss}
N -1140 -370 -1140 -270 {lab=vin_n}
N -1220 -270 -1140 -270 {lab=vin_n}
N -1220 -510 -1220 -270 {lab=vin_n}
N -1220 -510 -840 -510 {lab=vin_n}
N -840 -510 -840 -450 {lab=vin_n}
N -810 -450 -600 -450 {lab=vin_n}
N -600 -370 -600 -240 {lab=#net1}
N -600 -240 -600 -230 {lab=#net1}
N -900 -230 -600 -230 {lab=#net1}
N -900 -370 -900 -230 {lab=#net1}
C {capa.sym} -880 -320 0 0 {name=C3
m=1
value=500f
footprint=1206
device="ceramic capacitor"}
C {capa.sym} -800 -320 0 0 {name=C4
m=1
value=500f
footprint=1206
device="ceramic capacitor"}
C {isource.sym} -1010 -280 0 0 {name=I0 value=10u}
C {lab_wire.sym} -1040 -290 3 1 {name=p1 sig_type=std_logic lab=vss}
C {lab_wire.sym} -850 -250 0 1 {name=p2 sig_type=std_logic lab=vss}
C {lab_wire.sym} -1010 -210 3 1 {name=p3 sig_type=std_logic lab=vss}
C {lab_wire.sym} -1040 -530 3 0 {name=p4 sig_type=std_logic lab=vdd}
C {vsource.sym} -1180 -360 0 1 {name=V5 value=1 savecurrent=false}
C {lab_wire.sym} -1180 -290 3 1 {name=p5 sig_type=std_logic lab=vss}
C {lab_wire.sym} -1140 -450 0 1 {name=p6 sig_type=std_logic lab=vin_p}
C {lab_wire.sym} -1140 -370 0 1 {name=p7 sig_type=std_logic lab=vin_n}
C {vsource.sym} -1390 -220 0 0 {name=V6 value=\{vin_cm\} savecurrent=false}
C {lab_wire.sym} -1390 -150 3 1 {name=p27 sig_type=std_logic lab=vss}
C {vsource.sym} -1450 -340 0 1 {name=V7 value="DC 0 AC 0.5 0" savecurrent=false}
C {lab_wire.sym} -1450 -410 3 0 {name=p28 sig_type=std_logic lab=vin_p}
C {lab_wire.sym} -1350 -410 3 0 {name=p29 sig_type=std_logic lab=vin_n}
C {vsource.sym} -1350 -340 0 0 {name=V8 value="DC 0 AC 0.5 180" savecurrent=false}
C {vsource.sym} -1040 -110 0 0 {name=V9 value=2 savecurrent=false}
C {lab_wire.sym} -1040 -40 3 1 {name=p24 sig_type=std_logic lab=vss}
C {lab_wire.sym} -1040 -180 3 0 {name=p25 sig_type=std_logic lab=vdd}
C {vsource.sym} -1140 -110 0 0 {name=V10 value=0 savecurrent=false}
C {lab_wire.sym} -1140 -180 3 0 {name=p26 sig_type=std_logic lab=vss}
C {gnd.sym} -1140 -40 0 0 {name=l8 lab=0}
C {lab_wire.sym} -1370 -290 0 0 {name=p10 sig_type=std_logic lab=vin_cm}
C {lab_wire.sym} -1010 -340 1 1 {name=p11 sig_type=std_logic lab=ib}
C {lab_wire.sym} -1080 -410 0 0 {name=p12 sig_type=std_logic lab=vocm_set}
C {/foss/designs/sample-ota_gf180mcuD-main/xschem/top_level/top_level.sym} -1040 -330 0 0 {name=x3}
C {capa.sym} -340 -320 0 0 {name=C5
m=1
value=500f
footprint=1206
device="ceramic capacitor"}
C {capa.sym} -260 -320 0 0 {name=C6
m=1
value=500f
footprint=1206
device="ceramic capacitor"}
C {isource.sym} -470 -280 0 0 {name=I1 value=10u}
C {lab_wire.sym} -500 -290 3 1 {name=p13 sig_type=std_logic lab=vss}
C {lab_wire.sym} -310 -250 0 1 {name=p14 sig_type=std_logic lab=vss}
C {lab_wire.sym} -470 -210 3 1 {name=p15 sig_type=std_logic lab=vss}
C {lab_wire.sym} -500 -530 3 0 {name=p16 sig_type=std_logic lab=vdd}
C {vsource.sym} -640 -360 0 1 {name=V11 value=1 savecurrent=false}
C {lab_wire.sym} -640 -290 3 1 {name=p17 sig_type=std_logic lab=vss}
C {lab_wire.sym} -340 -450 0 0 {name=p20 sig_type=std_logic lab=vout_p}
C {lab_wire.sym} -340 -370 0 0 {name=p21 sig_type=std_logic lab=vout_n}
C {lab_wire.sym} -470 -340 1 1 {name=p22 sig_type=std_logic lab=ib}
C {lab_wire.sym} -540 -410 0 0 {name=p23 sig_type=std_logic lab=vocm_set}
C {/foss/designs/sample-ota_gf180mcuD-main/xschem/top_level/top_level.sym} -500 -330 0 0 {name=x4}
C {code_shown.sym} -1140 -710 0 0 {name=s1 only_toplevel=false value=
.control
save all

ac dec 100 0.1 1G

let vin_diff = v(vin_p)-v(vin_n)
let vout_diff = v(vout_p)-v(vout_n)
let H = vout_diff/vin_diff

plot db(H)
plot 180/pi*cph(H)

.endc}
