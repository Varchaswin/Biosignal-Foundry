v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
T {name=s1 only_toplevel=false value=".param vin_cm=0.8
.param vout_cm=1
.control
save all
save @m.x1.x1.xm1.m0[gm] @m.x1.x1.xm1.m0[gds] @m.x1.x1.xm1.m0[id] @m.x1.x1.xm1.m0[vdsat]
save @m.x1.x1.xm3.m0[gm] @m.x1.x1.xm3.m0[gds] @m.x1.x1.xm3.m0[id] @m.x1.x1.xm3.m0[vdsat]
save @m.x1.x1.xm5.m0[gm] @m.x1.x1.xm5.m0[gds] @m.x1.x1.xm5.m0[id] @m.x1.x1.xm5.m0[vdsat] 
save @m.x1.x2.xm1.m0[gm] @m.x1.x2.xm1.m0[gds] @m.x1.x2.xm1.m0[id] @m.x1.x2.xm1.m0[vdsat]
save @m.x1.x2.xm2.m0[gm] @m.x1.x2.xm2.m0[gds] @m.x1.x2.xm2.m0[id] @m.x1.x2.xm2.m0[vdsat]

op
write output_op.raw
*ac dec 1000 1 1G

*setplot ac1
*let vdiff = v(vout_p) - v(vout_n)
*write output.raw
.endc"} -510 -1580 0 0 0.4 0.4 {}
N 1250 -780 1370 -780 {lab=vin_n}
N 1370 -780 1370 -680 {lab=vin_n}
N 1250 -700 1290 -700 {lab=stage1_n}
N 1290 -700 1290 -680 {lab=stage1_n}
N 1290 -620 1290 -580 {lab=vss}
N 1290 -580 1370 -580 {lab=vss}
N 1370 -620 1370 -580 {lab=vss}
N 1160 -680 1160 -640 {lab=ib}
N 1130 -660 1130 -640 {lab=vss}
N 1130 -640 1130 -620 {lab=vss}
N 1160 -580 1160 -540 {lab=vss}
N 1130 -860 1130 -820 {lab=vdd}
N 1030 -780 1130 -780 {lab=vin_p}
N 1030 -700 1130 -700 {lab=#net1}
N 990 -740 1130 -740 {lab=#net2}
N 990 -740 990 -720 {lab=#net2}
N 990 -660 990 -620 {lab=vss}
N 780 -520 780 -500 {lab=vss}
N 780 -500 780 -480 {lab=vss}
N 780 -620 780 -580 {lab=vin_cm}
N 720 -620 780 -620 {lab=vin_cm}
N 720 -640 720 -620 {lab=vin_cm}
N 780 -620 790 -620 {lab=vin_cm}
N 790 -620 820 -620 {lab=vin_cm}
N 820 -640 820 -620 {lab=vin_cm}
N 720 -740 720 -700 {lab=vin_p}
N 820 -740 820 -700 {lab=vin_n}
N 1130 -410 1130 -390 {lab=vss}
N 1130 -510 1130 -470 {lab=vdd}
N 1130 -390 1130 -370 {lab=vss}
N 1030 -410 1030 -370 {lab=0}
N 1030 -510 1030 -470 {lab=vss}
N 1790 -780 1910 -780 {lab=vout_p}
N 1910 -780 1910 -680 {lab=vout_p}
N 1790 -700 1830 -700 {lab=vout_n}
N 1830 -700 1830 -680 {lab=vout_n}
N 1830 -620 1830 -580 {lab=vss}
N 1830 -580 1910 -580 {lab=vss}
N 1910 -620 1910 -580 {lab=vss}
N 1700 -680 1700 -640 {lab=ib}
N 1670 -660 1670 -640 {lab=vss}
N 1670 -640 1670 -620 {lab=vss}
N 1700 -580 1700 -540 {lab=vss}
N 1670 -860 1670 -820 {lab=vdd}
N 1570 -780 1670 -780 {lab=stage1_n}
N 1570 -700 1670 -700 {lab=vout_n}
N 1530 -740 1670 -740 {lab=vocm_set}
N 1530 -740 1530 -720 {lab=vocm_set}
N 1530 -660 1530 -620 {lab=vss}
N 950 -560 1030 -560 {lab=vin_n}
N 950 -840 950 -600 {lab=vin_n}
N 950 -840 1330 -840 {lab=vin_n}
N 1330 -840 1330 -780 {lab=vin_n}
N 1270 -700 1270 -560 {lab=stage1_n}
N 1570 -700 1570 -530 {lab=vout_n}
N 1570 -530 1760 -530 {lab=vout_n}
N 1270 -560 1460 -560 {lab=stage1_n}
N 1460 -780 1460 -560 {lab=stage1_n}
N 1460 -780 1570 -780 {lab=stage1_n}
N 1760 -530 1780 -530 {lab=vout_n}
N 1780 -530 1800 -530 {lab=vout_n}
N 1800 -700 1800 -530 {lab=vout_n}
N 950 -600 950 -560 {lab=vin_n}
N 1030 -700 1030 -660 {lab=#net1}
N 1030 -600 1030 -560 {lab=vin_n}
C {code_shown.sym} 20 -1100 0 0 {name=s1 only_toplevel=false value=".param vin_cm=0.8
.param vout_cm=1

.control
save all

ac dec 100 0.1 1G

let vin_diff = v(vin_p)-v(vin_n)
let vout_diff = v(vout_p)-v(vout_n)
let H = vout_diff/vin_diff

plot db(H)
plot 180/pi*cph(H)
let stage1_diff = v(vin_n)-v(stage1_n)
plot db(vout_diff/stage1_diff)

plot db(stage1_diff/vin_diff)
plot db(vout_diff/stage1_diff)
plot db (vout_diff/vin_diff)

.endc"}
C {devices/code_shown.sym} 0 -660 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
.lib $::180MCU_MODELS/sm141064.ngspice cap_mim
.lib $::180MCU_MODELS/sm141064.ngspice res_typical
.lib $::180MCU_MODELS/sm141064.ngspice moscap_typical
.lib $::180MCU_MODELS/sm141064.ngspice mimcap_typical
"}
C {capa.sym} 1290 -650 0 0 {name=C3
m=1
value=500f
footprint=1206
device="ceramic capacitor"}
C {capa.sym} 1370 -650 0 0 {name=C4
m=1
value=500f
footprint=1206
device="ceramic capacitor"}
C {isource.sym} 1160 -610 0 0 {name=I0 value=10u}
C {lab_wire.sym} 1130 -620 3 1 {name=p1 sig_type=std_logic lab=vss}
C {lab_wire.sym} 1320 -580 0 1 {name=p2 sig_type=std_logic lab=vss}
C {lab_wire.sym} 1160 -540 3 1 {name=p3 sig_type=std_logic lab=vss}
C {lab_wire.sym} 1130 -860 3 0 {name=p4 sig_type=std_logic lab=vdd}
C {vsource.sym} 990 -690 0 1 {name=V5 value=1 savecurrent=false}
C {lab_wire.sym} 990 -620 3 1 {name=p5 sig_type=std_logic lab=vss}
C {lab_wire.sym} 1030 -780 0 1 {name=p6 sig_type=std_logic lab=vin_p}
C {lab_wire.sym} 970 -560 0 1 {name=p7 sig_type=std_logic lab=vin_n}
C {vsource.sym} 780 -550 0 0 {name=V6 value=\{vin_cm\} savecurrent=false}
C {lab_wire.sym} 780 -480 3 1 {name=p27 sig_type=std_logic lab=vss}
C {vsource.sym} 720 -670 0 1 {name=V7 value="DC 0 AC 0.5 0" savecurrent=false}
C {lab_wire.sym} 720 -740 3 0 {name=p28 sig_type=std_logic lab=vin_p}
C {lab_wire.sym} 820 -740 3 0 {name=p29 sig_type=std_logic lab=vin_n}
C {vsource.sym} 820 -670 0 0 {name=V8 value="DC 0 AC 0.5 180" savecurrent=false}
C {vsource.sym} 1130 -440 0 0 {name=V9 value=2 savecurrent=false}
C {lab_wire.sym} 1130 -370 3 1 {name=p24 sig_type=std_logic lab=vss}
C {lab_wire.sym} 1130 -510 3 0 {name=p25 sig_type=std_logic lab=vdd}
C {vsource.sym} 1030 -440 0 0 {name=V10 value=0 savecurrent=false}
C {lab_wire.sym} 1030 -510 3 0 {name=p26 sig_type=std_logic lab=vss}
C {gnd.sym} 1030 -370 0 0 {name=l8 lab=0}
C {lab_wire.sym} 800 -620 0 0 {name=p10 sig_type=std_logic lab=vin_cm}
C {lab_wire.sym} 1160 -670 1 1 {name=p11 sig_type=std_logic lab=ib}
C {lab_wire.sym} 1220 -460 0 0 {name=p12 sig_type=std_logic lab=vocm_set}
C {/foss/designs/sample-ota_gf180mcuD-main/xschem/top_level/top_level.sym} 1130 -660 0 0 {name=x3}
C {capa.sym} 1830 -650 0 0 {name=C5
m=1
value=500f
footprint=1206
device="ceramic capacitor"}
C {capa.sym} 1910 -650 0 0 {name=C6
m=1
value=500f
footprint=1206
device="ceramic capacitor"}
C {isource.sym} 1700 -610 0 0 {name=I1 value=10u}
C {lab_wire.sym} 1670 -620 3 1 {name=p13 sig_type=std_logic lab=vss}
C {lab_wire.sym} 1860 -580 0 1 {name=p14 sig_type=std_logic lab=vss}
C {lab_wire.sym} 1700 -540 3 1 {name=p15 sig_type=std_logic lab=vss}
C {lab_wire.sym} 1670 -860 3 0 {name=p16 sig_type=std_logic lab=vdd}
C {vsource.sym} 1530 -690 0 1 {name=V11 value=1 savecurrent=false}
C {lab_wire.sym} 1530 -620 3 1 {name=p17 sig_type=std_logic lab=vss}
C {lab_wire.sym} 1830 -780 0 0 {name=p20 sig_type=std_logic lab=vout_p}
C {lab_wire.sym} 1830 -700 0 0 {name=p21 sig_type=std_logic lab=vout_n}
C {lab_wire.sym} 1700 -670 1 1 {name=p22 sig_type=std_logic lab=ib}
C {lab_wire.sym} 1630 -740 0 0 {name=p23 sig_type=std_logic lab=vocm_set}
C {/foss/designs/sample-ota_gf180mcuD-main/xschem/top_level/top_level.sym} 1670 -660 0 0 {name=x4}
C {lab_pin.sym} 1460 -560 0 0 {name=p8 sig_type=std_logic lab=stage1_n}
C {capa.sym} 1030 -630 2 0 {name=C1
m=1
value=500f
footprint=1206
device="ceramic capacitor"}
